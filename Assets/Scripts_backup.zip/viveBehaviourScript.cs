﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class viveBehaviourScript : MonoBehaviour
{
    // Start is called before the first frame update

    /*private SteamVR_TrackedObject trackedObj;
    // 2
    private SteamVR_Controller.Device Controller
    {
        get { return SteamVR_Controller.Input((int)trackedObj.index); }
    }
    void Awake()
    {
        trackedObj = GetComponent<SteamVR_TrackedObject>();
    }
    // Update is called once per frame*/
    void Update()
    {
            
    }
}
